"""Training, evaluation, saving and loading of the risk model."""
import json

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier

from .config import (CATEGORICAL_FEATURES, FEATURES, META_FILE, MODEL_DIR,
                     MODEL_FILE, NUMERIC_FEATURES, RANDOM_STATE, RISK_LABELS)


def _preprocessor() -> ColumnTransformer:
    return ColumnTransformer(
        [
            ("num", "passthrough", NUMERIC_FEATURES),
            ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
        ]
    )


def _pipeline(estimator) -> Pipeline:
    return Pipeline([("prep", _preprocessor()), ("clf", estimator)])


def train_and_evaluate(df: pd.DataFrame):
    """Train a Decision Tree and a Random Forest, keep the better one."""
    X, y = df[FEATURES], df["risk"]
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    candidates = {
        "Decision Tree": (
            DecisionTreeClassifier(class_weight="balanced", random_state=RANDOM_STATE),
            {"clf__max_depth": [3, 4, 5, 6, 8], "clf__min_samples_leaf": [2, 5, 10]},
        ),
        "Random Forest": (
            RandomForestClassifier(class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1),
            {"clf__n_estimators": [100, 300], "clf__max_depth": [None, 6, 10],
             "clf__min_samples_leaf": [1, 3]},
        ),
    }

    results, fitted = {}, {}
    for name, (est, grid) in candidates.items():
        search = GridSearchCV(_pipeline(est), grid, cv=cv, scoring="f1_macro", n_jobs=-1)
        search.fit(X_tr, y_tr)
        pred = search.predict(X_te)
        results[name] = {
            "best_params": {k.replace("clf__", ""): v for k, v in search.best_params_.items()},
            "cv_f1_macro": round(float(search.best_score_), 4),
            "test_accuracy": round(float(accuracy_score(y_te, pred)), 4),
            "test_f1_macro": round(float(f1_score(y_te, pred, average="macro")), 4),
            "confusion_matrix": confusion_matrix(y_te, pred, labels=RISK_LABELS).tolist(),
            "report": classification_report(y_te, pred, labels=RISK_LABELS,
                                            output_dict=True, zero_division=0),
        }
        fitted[name] = search.best_estimator_

    best_name = max(results, key=lambda n: results[n]["test_f1_macro"])

    # Importances for the best model
    best = fitted[best_name]
    names = best.named_steps["prep"].get_feature_names_out()
    names = [n.split("__", 1)[1] for n in names]
    imps = best.named_steps["clf"].feature_importances_
    importances = sorted(zip(names, map(float, imps)), key=lambda t: -t[1])

    # Defaults used to fill questions the quick assessment does not ask
    defaults = {c: float(df[c].median()) for c in NUMERIC_FEATURES}
    defaults.update({c: str(df[c].mode().iloc[0]) for c in CATEGORICAL_FEATURES})

    meta = {
        "best_model": best_name,
        "results": results,
        "importances": importances,
        "defaults": defaults,
        "n_rows": int(len(df)),
        "class_counts": df["risk"].value_counts().to_dict(),
        "ranges": {c: [float(df[c].min()), float(df[c].max())] for c in NUMERIC_FEATURES},
    }
    return fitted, best_name, meta, (X_te, y_te)


def save(fitted, best_name, meta):
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump({"models": fitted, "best": best_name}, MODEL_FILE)
    META_FILE.write_text(json.dumps(meta, indent=2))


def load():
    """Return (bundle, meta). bundle = {'models': {...}, 'best': name}."""
    if not MODEL_FILE.exists():
        raise FileNotFoundError("No trained model found. Run:  python train_model.py")
    return joblib.load(MODEL_FILE), json.loads(META_FILE.read_text())


def predict_one(bundle, record: dict, model_name: str | None = None):
    """Predict risk for one student. Returns (label, {label: probability})."""
    name = model_name or bundle["best"]
    pipe = bundle["models"][name]
    row = pd.DataFrame([record])[FEATURES]
    label = pipe.predict(row)[0]
    probs = dict(zip(pipe.classes_, pipe.predict_proba(row)[0]))
    return label, {k: float(probs.get(k, 0.0)) for k in RISK_LABELS}


def predict_many(bundle, df: pd.DataFrame, model_name: str | None = None) -> pd.DataFrame:
    name = model_name or bundle["best"]
    pipe = bundle["models"][name]
    out = df.copy()
    out["predicted_risk"] = pipe.predict(df[FEATURES])
    proba = pipe.predict_proba(df[FEATURES])
    for i, c in enumerate(pipe.classes_):
        out[f"p_{c}"] = proba[:, i].round(3)
    return out

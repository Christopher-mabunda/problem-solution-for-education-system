"""Central configuration for EduPrediction."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"

DATA_FILE = DATA_DIR / "student-por.csv"      # real UCI dataset (semicolon separated)
MODEL_FILE = MODEL_DIR / "risk_model.joblib"
META_FILE = MODEL_DIR / "model_meta.json"

RANDOM_STATE = 42

# ---- Risk categories (from the project documentation / poster) -------------
#   High   : G3 < 10
#   Medium : 10 <= G3 <= 13
#   Low    : G3 >= 14
RISK_LABELS = ["Low", "Medium", "High"]
RISK_COLOURS = {"Low": "#2e9e5b", "Medium": "#e0a526", "High": "#d64545"}

# ---- Features (from the documentation, section 5) ---------------------------
NUMERIC_FEATURES = [
    "age", "studytime", "absences", "failures", "Medu", "Fedu", "G1", "G2",
]
CATEGORICAL_FEATURES = ["sex", "famsup", "schoolsup", "internet"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
TARGET = "G3"

# The five short questions asked in the quick assessment (poster, step 2)
CORE_INPUTS = ["age", "sex", "studytime", "absences", "G2"]


def grade_to_risk(g3: float) -> str:
    """Convert a final grade (0-20) to a risk label."""
    if g3 < 10:
        return "High"
    if g3 < 14:
        return "Medium"
    return "Low"

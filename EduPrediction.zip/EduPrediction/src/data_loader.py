"""Load and clean the student-por dataset."""
import pandas as pd

from .config import DATA_FILE, FEATURES, TARGET, grade_to_risk


def load_raw(path=DATA_FILE) -> pd.DataFrame:
    """Read the UCI student-por.csv (semicolon separated)."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}.\n"
            "Place the UCI 'student-por.csv' file in the data/ folder, or run\n"
            "    python generate_sample_data.py\n"
            "to create a synthetic stand-in for testing."
        )
    df = pd.read_csv(path, sep=";")
    if df.shape[1] == 1:  # fallback if comma separated
        df = pd.read_csv(path)
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Keep needed columns, handle missing values, add the risk label."""
    needed = FEATURES + [TARGET]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    df = df[needed].copy()
    df = df.drop_duplicates()

    # Missing values: median for numbers, most frequent for categories
    for col in df.columns:
        if df[col].isna().any():
            if df[col].dtype.kind in "biufc":
                df[col] = df[col].fillna(df[col].median())
            else:
                df[col] = df[col].fillna(df[col].mode().iloc[0])

    df["risk"] = df[TARGET].apply(grade_to_risk)
    return df


def load_clean() -> pd.DataFrame:
    return clean(load_raw())

"""Rule-based recommendations and a simple recommendation chatbot."""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Recommendations (poster, section 07)
# ---------------------------------------------------------------------------

def recommend(record: dict, risk: str) -> list[str]:
    """Return practical, personalised actions for a student."""
    tips: list[str] = []

    if record.get("studytime", 2) <= 2:
        tips.append("Increase study time: aim for at least 5 to 10 focused hours per week "
                    "(weekly study time level 3 or higher).")
    if record.get("absences", 0) >= 5:
        tips.append("Improve attendance: absences are high. Speak to the lecturer about "
                    "the causes and agree on an attendance plan.")
    if record.get("failures", 0) >= 1:
        tips.append("Request academic support: previous failures suggest the student would "
                    "benefit from tutoring or a catch-up programme.")
    if record.get("G2", 10) < 10:
        tips.append("Request academic support: the latest grade (G2) is below the pass "
                    "mark. Book a meeting with a counsellor or subject lecturer.")
    if str(record.get("schoolsup", "no")) == "no" and risk != "Low":
        tips.append("Consider enrolling in extra school support classes.")
    if str(record.get("internet", "yes")) == "no" and risk != "Low":
        tips.append("Provide access to campus or library internet and online learning resources.")

    if risk == "High":
        tips.insert(0, "Priority: arrange an intervention meeting within the next week.")
    elif risk == "Medium":
        tips.append("Monitor progress closely and review again after the next assessment.")
    else:
        tips.append("Keep up the good work and continue current study habits.")

    seen, out = set(), []
    for t in tips:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


RISK_SUMMARY = {
    "Low": "On track (predicted final grade G3 of 14 or higher).",
    "Medium": "Monitor closely (predicted G3 of 10 to 13).",
    "High": "Needs support (predicted G3 below 10).",
}

# ---------------------------------------------------------------------------
# Simple keyword chatbot
# ---------------------------------------------------------------------------

_FAQ = [
    (("risk level", "what is high", "what is low", "what is medium", "categories", "meaning"),
     "Risk levels are based on the predicted final grade (G3):\n"
     "- **Low**: G3 of 14 or higher. On track.\n"
     "- **Medium**: G3 of 10 to 13. Monitor closely.\n"
     "- **High**: G3 below 10. Needs support."),
    (("study", "studying", "study time"),
     "Study time is recorded in levels: 1 = under 2 hours, 2 = 2-5 hours, 3 = 5-10 hours, "
     "4 = over 10 hours per week. Moving up one level is one of the simplest ways to improve results."),
    (("absence", "absent", "attendance", "skip"),
     "Frequent absences are linked to weaker results. Encourage regular attendance and "
     "speak to the student about any barriers (transport, health, family)."),
    (("g1", "g2", "g3", "grade", "mark"),
     "G1 and G2 are the first and second period grades, G3 is the final grade (0-20). The model "
     "relies heavily on G2 because recent performance is the best early indicator of the final result."),
    (("model", "algorithm", "random forest", "decision tree", "accuracy"),
     "EduPrediction trains a Decision Tree and a Random Forest and uses the better performing one. "
     "See the 'Model Performance' page for accuracy and confusion matrices."),
    (("help", "support", "tutor", "counsel", "intervention"),
     "For High risk students: arrange an intervention meeting, offer tutoring, and agree on a "
     "weekly follow-up. For Medium risk: monitor closely and review after the next assessment."),
    (("data", "privacy", "secure"),
     "Student data should only be accessible to authorised staff. Predictions are guidance, not a "
     "final judgement, and should be combined with professional insight."),
    (("hello", "hi", "hey"),
     "Hello! I can explain risk levels, study time, attendance and recommended actions. "
     "Run an assessment first to get personalised advice."),
]


def chatbot_reply(message: str, last_result: dict | None = None) -> str:
    """Return an answer to a free-text question."""
    msg = message.lower().strip()
    if not msg:
        return "Please type a question."

    if last_result and any(k in msg for k in ("my result", "my risk", "what should i do",
                                               "next step", "advice", "recommend")):
        tips = "\n".join(f"- {t}" for t in last_result["tips"])
        return (f"Your latest assessment shows **{last_result['risk']} risk**. "
                f"{RISK_SUMMARY[last_result['risk']]}\n\nRecommended actions:\n{tips}")

    words = set(msg.replace("?", " ").replace(".", " ").replace(",", " ").split())
    for keys, answer in _FAQ:
        if any((k in msg) if " " in k or len(k) > 3 else (k in words) for k in keys):
            return answer

    return ("I can help with risk levels, study time, attendance, grades and support options. "
            "Try asking: *What does High risk mean?* or *What should I do next?*")
